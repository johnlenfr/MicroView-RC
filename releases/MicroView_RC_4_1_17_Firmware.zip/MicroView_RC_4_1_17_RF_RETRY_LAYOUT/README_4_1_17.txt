MicroView RC 4.1.17 - RF retry display layout

TX: 4.1.17
ATtiny85: 3.17.1 (unchanged)
RX: 3.19a (unchanged)

Change from 4.1.16:
- RF DEBUG latency/retry line is now visually separated.
- Display example: L1.5MS/R0 instead of L1.5MSR0.
- A compact manually drawn slash is used so the 64-pixel display can still fit the worst case L16.8MS/R10.
- R still comes directly from nRF24L01+ OBSERVE_TX.ARC_CNT for compatibility with older RF24 libraries.
- No change to RF timing, retry settings, ATtiny protocol, receiver firmware, menus, endpoints, or alerts.

Only the TX needs to be reflashed for this change.
